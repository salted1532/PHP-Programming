<?php
    //print_r($_GET);
    $tours = $_GET['tour']; // array
    print_r($tours);
?>