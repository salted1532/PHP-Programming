<?php
    //$_GET['userid'], $_GET['passwd']

    //print_r($_GET);

    echo $_GET['userid'] . ' : ' . $_GET['passwd'];
?>