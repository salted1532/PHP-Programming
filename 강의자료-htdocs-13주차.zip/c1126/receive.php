<?php
    //$_GET['userid']
    //print_r($_GET);
    echo $_GET['userid'] . ' : ' . $_GET['passwd'];
?>